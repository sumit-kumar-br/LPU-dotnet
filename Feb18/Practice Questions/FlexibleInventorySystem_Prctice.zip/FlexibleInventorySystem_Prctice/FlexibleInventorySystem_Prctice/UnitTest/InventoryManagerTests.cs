﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlexibleInventorySystem_Prctice.UnitTest
{
    // Example test cases (not provided - students should create their own)
    [TestClass]
    public class InventoryManagerTests
    {
        [TestMethod]
        public void AddProduct_ValidProduct_ReturnsTrue()
        {
            // TODO: Write test
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void AddProduct_NullProduct_ThrowsException()
        {
            // TODO: Write test
        }

        // TODO: Add more test methods
    }
}
